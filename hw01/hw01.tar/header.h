/*
 * header.h
 *
 *  Created on: Jan 30, 2017
 *      Author: Brian Clinkenbeard
 */

#ifndef HEADER_H_
#define HEADER_H_

#include <iostream>
#include <string>
using namespace std;

#endif /* HEADER_H_ */
